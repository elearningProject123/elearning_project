<?php
// Include necessary files
include('../includes/db_connection.php');
include('../includes/functions.php');

// Fetch all users from the database
$users = get_all_users();

// Check if any users are available
if($users) {
    // Display users
    echo "<h2>Registered Users</h2>";
    echo "<ul>";
    foreach($users as $user) {
        echo "<li>" . $user['username'] . "</li>";
    }
    echo "</ul>";
} else {
    echo "No users registered.";
}
?>
