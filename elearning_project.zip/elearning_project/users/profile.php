<?php
// Include necessary files
include('../includes/db_connection.php');
include('../includes/functions.php');

// Check if user is logged in
session_start();
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page if user is not logged in
    header("Location: login.php");
    exit();
}

// Fetch user details from the database
$user_id = $_SESSION['user_id'];
$user = get_user_by_id($user_id);

// Check if user exists
if (!$user) {
    // Redirect to login page if user does not exist
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <!-- Add your CSS links here -->
</head>
<body>
    <h2>User Profile</h2>
    <p><strong>Username:</strong> <?php echo $user['username']; ?></p>
    <p><strong>Email:</strong> <?php echo $user['email']; ?></p>
    <!-- You can display additional user details here -->
</body>
</html>
