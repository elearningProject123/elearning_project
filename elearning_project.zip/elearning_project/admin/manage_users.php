<?php
// Include necessary files
include('../includes/db_connection.php');
include('../includes/functions.php');

// Check if admin is logged in
session_start();
if (!isset($_SESSION['admin_id'])) {
    // Redirect to admin login page if admin is not logged in
    header("Location: login.php");
    exit();
}

// Fetch all users from the database
$users = get_all_users();

// Check if any users are available
if (!$users) {
    $message = "No users available.";
}

// Handle user deletion
if (isset($_POST['delete_user'])) {
    $user_id = $_POST['user_id'];
    $result = delete_user($user_id);
    if ($result) {
        // Refresh the page after successful deletion
        header("Location: manage_users.php");
        exit();
    } else {
        $message = "Failed to delete user. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users</title>
    <!-- Add your CSS links here -->
</head>
<body>
    <h2>Manage Users</h2>
    <?php if (isset($message)) { echo "<p>$message</p>"; } ?>
    <ul>
        <?php foreach ($users as $user): ?>
            <li>
                <?php echo $user['username']; ?>
                <a href="edit_user.php?user_id=<?php echo $user['id']; ?>">Edit</a>
                <form method="post" action="">
                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                    <input type="submit" name="delete_user" value="Delete">
                </form>
            </li>
        <?php endforeach; ?>
    </ul>
    <p><a href="index.php">Back to Dashboard</a></p>
    <p><a href="logout.php">Logout</a></p>
</body>
</html>
