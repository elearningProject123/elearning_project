<?php
// Include necessary files
include('../includes/db_connection.php');
include('../includes/functions.php');

// Check if admin is logged in
session_start();
if (!isset($_SESSION['admin_id'])) {
    // Redirect to admin login page if admin is not logged in
    header("Location: login.php");
    exit();
}

// Fetch all courses from the database
$courses = get_all_courses();

// Check if any courses are available
if (!$courses) {
    $message = "No courses available.";
}

// Handle course deletion
if (isset($_POST['delete_course'])) {
    $course_id = $_POST['course_id'];
    $result = delete_course($course_id);
    if ($result) {
        // Refresh the page after successful deletion
        header("Location: manage_courses.php");
        exit();
    } else {
        $message = "Failed to delete course. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Courses</title>
    <!-- Add your CSS links here -->
</head>
<body>
    <h2>Manage Courses</h2>
    <?php if (isset($message)) { echo "<p>$message</p>"; } ?>
    <a href="add_course.php">Add New Course</a>
    <ul>
        <?php foreach ($courses as $course): ?>
            <li>
                <?php echo $course['title']; ?>
                <a href="edit_course.php?course_id=<?php echo $course['id']; ?>">Edit</a>
                <form method="post" action="">
                    <input type="hidden" name="course_id" value="<?php echo $course['id']; ?>">
                    <input type="submit" name="delete_course" value="Delete">
                </form>
            </li>
        <?php endforeach; ?>
    </ul>
    <p><a href="index.php">Back to Dashboard</a></p>
    <p><a href="logout.php">Logout</a></p>
</body>
</html>
