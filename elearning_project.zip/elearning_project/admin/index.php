<?php
// Include necessary files
include('../includes/db_connection.php');
include('../includes/functions.php');

// Check if admin is logged in
session_start();
if (!isset($_SESSION['admin_id'])) {
    // Redirect to admin login page if admin is not logged in
    header("Location: login.php");
    exit();
}

// Fetch admin details from the database
$admin_id = $_SESSION['admin_id'];
$admin = get_admin_by_id($admin_id);

// Check if admin exists
if (!$admin) {
    // Redirect to admin login page if admin does not exist
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <!-- Add your CSS links here -->
</head>
<body>
    <h2>Welcome, <?php echo $admin['username']; ?>!</h2>
    <p>This is the admin dashboard. You can manage various aspects of the e-learning platform from here.</p>
    <!-- Add links to different admin functionalities/pages here -->
    <ul>
        <li><a href="manage_courses.php">Manage Courses</a></li>
        <li><a href="manage_users.php">Manage Users</a></li>
        <!-- Add more links as needed -->
    </ul>
    <p><a href="logout.php">Logout</a></p>
</body>
</html>
