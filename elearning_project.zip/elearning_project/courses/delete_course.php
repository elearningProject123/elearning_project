<?php
// Include necessary files
include('../includes/db_connection.php');
include('../includes/functions.php');

// Check if course ID is provided in the URL
if(isset($_GET['course_id'])) {
    // Sanitize the input
    $course_id = sanitize_input($_GET['course_id']);
    
    // Delete the course from the database
    $result = delete_course($course_id);

    // Check if the course is deleted successfully
    if($result) {
        // Redirect to index.php or display a success message
        header("Location: index.php");
        exit();
    } else {
        // Display an error message if deletion fails
        echo "Failed to delete course. Please try again.";
    }
} else {
    // Display an error message for invalid request
    echo "Invalid request.";
}
?>
