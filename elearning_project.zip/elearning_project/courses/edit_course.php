<?php
// Include necessary files
include('../includes/db_connection.php');
include('../includes/functions.php');

// Initialize variables
$id = $title = $description = $instructor = $duration = '';
$errors = array();

// Check if course ID is provided in the URL
if(isset($_GET['course_id'])) {
    // Sanitize the input
    $id = sanitize_input($_GET['course_id']);
    
    // Fetch course details from the database
    $course = get_course_details($id);

    // Check if the course exists
    if($course) {
        // Populate form fields with course details
        $title = $course['title'];
        $description = $course['description'];
        $instructor = $course['instructor'];
        $duration = $course['duration'];
    } else {
        // Redirect to index.php or display an error message
        header("Location: index.php");
        exit();
    }
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize input data
    $title = sanitize_input($_POST["title"]);
    $description = sanitize_input($_POST["description"]);
    $instructor = sanitize_input($_POST["instructor"]);
    $duration = sanitize_input($_POST["duration"]);

    // Validate input
    if (empty($title)) {
        $errors[] = "Title is required";
    }
    if (empty($description)) {
        $errors[] = "Description is required";
    }
    if (empty($instructor)) {
        $errors[] = "Instructor is required";
    }
    if (empty($duration)) {
        $errors[] = "Duration is required";
    }

    // If no errors, update course in the database
    if (empty($errors)) {
        $result = update_course($id, $title, $description, $instructor, $duration);
        if ($result) {
            // Course updated successfully
            header("Location: view_course.php?course_id=$id");
            exit();
        } else {
            $errors[] = "Failed to update course. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Course</title>
    <!-- Add your CSS links here -->
</head>
<body>
    <h2>Edit Course</h2>
    <?php
    // Display errors, if any
    if (!empty($errors)) {
        echo "<ul>";
        foreach ($errors as $error) {
            echo "<li>$error</li>";
        }
        echo "</ul>";
    }
    ?>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . '?course_id=' . $id; ?>">
        <label for="title">Title:</label><br>
        <input type="text" id="title" name="title" value="<?php echo $title; ?>"><br><br>
        <label for="description">Description:</label><br>
        <textarea id="description" name="description"><?php echo $description; ?></textarea><br><br>
        <label for="instructor">Instructor:</label><br>
        <input type="text" id="instructor" name="instructor" value="<?php echo $instructor; ?>"><br><br>
        <label for="duration">Duration (hours):</label><br>
        <input type="number" id="duration" name="duration" value="<?php echo $duration; ?>"><br><br>
        <input type="submit" value="Update Course">
    </form>
</body>
</html>
