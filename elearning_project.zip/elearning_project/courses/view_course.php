<?php
// Include necessary files
include('../includes/db_connection.php');
include('../includes/functions.php');

// Check if course ID is provided in the URL
if(isset($_GET['course_id'])) {
    // Sanitize the input
    $course_id = sanitize_input($_GET['course_id']);
    
    // Fetch course details from the database
    $course = get_course_details($course_id);

    // Check if the course exists
    if($course) {
        // Display course details
        echo "<h2>Course Details</h2>";
        echo "<p><strong>Title:</strong> " . $course['title'] . "</p>";
        echo "<p><strong>Description:</strong> " . $course['description'] . "</p>";
        echo "<p><strong>Instructor:</strong> " . $course['instructor'] . "</p>";
        echo "<p><strong>Duration:</strong> " . $course['duration'] . " hours</p>";
        // You can add more details as needed
    } else {
        echo "Course not found.";
    }
} else {
    echo "Invalid request.";
}
?>
