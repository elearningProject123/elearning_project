<?php
// Include necessary files
include('../includes/db_connection.php');
include('../includes/functions.php');

// Fetch all courses from the database
$courses = get_all_courses();

// Check if any courses are available
if($courses) {
    // Display courses
    echo "<h2>Available Courses</h2>";
    echo "<ul>";
    foreach($courses as $course) {
        echo "<li><a href='view_course.php?course_id=" . $course['id'] . "'>" . $course['title'] . "</a></li>";
    }
    echo "</ul>";
} else {
    echo "No courses available.";
}
?>
