<?php
// Include necessary files
include('../includes/db_connection.php');
include('../includes/functions.php');

// Check if lesson ID is provided in the URL
if(isset($_GET['lesson_id'])) {
    // Sanitize the input
    $lesson_id = sanitize_input($_GET['lesson_id']);
    
    // Delete the lesson from the database
    $result = delete_lesson($lesson_id);

    // Check if the lesson is deleted successfully
    if($result) {
        // Redirect to index.php or display a success message
        header("Location: index.php");
        exit();
    } else {
        // Display an error message if deletion fails
        echo "Failed to delete lesson. Please try again.";
    }
} else {
    // Display an error message for invalid request
    echo "Invalid request.";
}
?>
