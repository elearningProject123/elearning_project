<?php
// Include necessary files
include('../includes/db_connection.php');
include('../includes/functions.php');

// Initialize variables
$id = $title = $description = $content = '';
$errors = array();

// Check if lesson ID is provided in the URL
if(isset($_GET['lesson_id'])) {
    // Sanitize the input
    $id = sanitize_input($_GET['lesson_id']);
    
    // Fetch lesson details from the database
    $lesson = get_lesson_details($id);

    // Check if the lesson exists
    if($lesson) {
        // Populate form fields with lesson details
        $title = $lesson['title'];
        $description = $lesson['description'];
        $content = $lesson['content'];
    } else {
        // Redirect to index.php or display an error message
        header("Location: index.php");
        exit();
    }
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize input data
    $title = sanitize_input($_POST["title"]);
    $description = sanitize_input($_POST["description"]);
    $content = sanitize_input($_POST["content"]);

    // Validate input
    if (empty($title)) {
        $errors[] = "Title is required";
    }
    if (empty($description)) {
        $errors[] = "Description is required";
    }
    if (empty($content)) {
        $errors[] = "Content is required";
    }

    // If no errors, update lesson in the database
    if (empty($errors)) {
        $result = update_lesson($id, $title, $description, $content);
        if ($result) {
            // Lesson updated successfully
            header("Location: view_lesson.php?lesson_id=$id");
            exit();
        } else {
            $errors[] = "Failed to update lesson. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Lesson</title>
    <!-- Add your CSS links here -->
</head>
<body>
    <h2>Edit Lesson</h2>
    <?php
    // Display errors, if any
    if (!empty($errors)) {
        echo "<ul>";
        foreach ($errors as $error) {
            echo "<li>$error</li>";
        }
        echo "</ul>";
    }
    ?>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . '?lesson_id=' . $id; ?>">
        <label for="title">Title:</label><br>
        <input type="text" id="title" name="title" value="<?php echo $title; ?>"><br><br>
        <label for="description">Description:</label><br>
        <textarea id="description" name="description"><?php echo $description; ?></textarea><br><br>
        <label for="content">Content:</label><br>
        <textarea id="content" name="content"><?php echo $content; ?></textarea><br><br>
        <input type="submit" value="Update Lesson">
    </form>
</body>
</html>
