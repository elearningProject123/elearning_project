<?php
// Include necessary files
include('../includes/db_connection.php');
include('../includes/functions.php');

// Check if lesson ID is provided in the URL
if(isset($_GET['lesson_id'])) {
    // Sanitize the input
    $lesson_id = sanitize_input($_GET['lesson_id']);
    
    // Fetch lesson details from the database
    $lesson = get_lesson_details($lesson_id);

    // Check if the lesson exists
    if($lesson) {
        // Display lesson details
        echo "<h2>Lesson Details</h2>";
        echo "<p><strong>Title:</strong> " . $lesson['title'] . "</p>";
        echo "<p><strong>Description:</strong> " . $lesson['description'] . "</p>";
        echo "<p><strong>Content:</strong><br>" . $lesson['content'] . "</p>";
        // You can add more details as needed
    } else {
        echo "Lesson not found.";
    }
} else {
    echo "Invalid request.";
}
?>
