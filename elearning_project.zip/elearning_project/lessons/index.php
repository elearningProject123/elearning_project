<?php
// Include necessary files
include('../includes/db_connection.php');
include('../includes/functions.php');

// Fetch all lessons from the database
$lessons = get_all_lessons();

// Check if any lessons are available
if($lessons) {
    // Display lessons
    echo "<h2>Available Lessons</h2>";
    echo "<ul>";
    foreach($lessons as $lesson) {
        echo "<li><a href='view_lesson.php?lesson_id=" . $lesson['id'] . "'>" . $lesson['title'] . "</a></li>";
    }
    echo "</ul>";
} else {
    echo "No lessons available.";
}
?>
