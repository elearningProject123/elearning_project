<?php
// Include necessary files
include('../includes/db_connection.php');
include('../includes/functions.php');

// Initialize variables
$title = $description = $content = '';
$errors = array();

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize input data
    $title = sanitize_input($_POST["title"]);
    $description = sanitize_input($_POST["description"]);
    $content = sanitize_input($_POST["content"]);

    // Validate input
    if (empty($title)) {
        $errors[] = "Title is required";
    }
    if (empty($description)) {
        $errors[] = "Description is required";
    }
    if (empty($content)) {
        $errors[] = "Content is required";
    }

    // If no errors, insert lesson into the database
    if (empty($errors)) {
        $result = create_lesson($title, $description, $content);
        if ($result) {
            // Lesson created successfully
            header("Location: index.php");
            exit();
        } else {
            $errors[] = "Failed to create lesson. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Lesson</title>
    <!-- Add your CSS links here -->
</head>
<body>
    <h2>Create New Lesson</h2>
    <?php
    // Display errors, if any
    if (!empty($errors)) {
        echo "<ul>";
        foreach ($errors as $error) {
            echo "<li>$error</li>";
        }
        echo "</ul>";
    }
    ?>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <label for="title">Title:</label><br>
        <input type="text" id="title" name="title" value="<?php echo $title; ?>"><br><br>
        <label for="description">Description:</label><br>
        <textarea id="description" name="description"><?php echo $description; ?></textarea><br><br>
        <label for="content">Content:</label><br>
        <textarea id="content" name="content"><?php echo $content; ?></textarea><br><br>
        <input type="submit" value="Create Lesson">
    </form>
</body>
</html>
