<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to E-Learning Platform</title>
    <!-- Add your CSS links here -->
</head>
<body>
    <h1>Welcome to E-Learning Platform</h1>
    <p>This is a platform where you can access various courses and lessons to enhance your knowledge.</p>
    <h2>Featured Courses</h2>
    <ul>
        <!-- Display featured courses here -->
        <li><a href="courses.php">Course 1</a></li>
        <li><a href="courses.php">Course 2</a></li>
        <li><a href="courses.php">Course 3</a></li>
        <!-- Add more courses as needed -->
    </ul>
    <p><a href="courses.php">View All Courses</a></p>
    <h2>Latest Lessons</h2>
    <ul>
        <!-- Display latest lessons here -->
        <li><a href="lessons.php">Lesson 1</a></li>
        <li><a href="lessons.php">Lesson 2</a></li>
        <li><a href="lessons.php">Lesson 3</a></li>
        <!-- Add more lessons as needed -->
    </ul>
    <p><a href="lessons.php">View All Lessons</a></p>
    <p><a href="admin/login.php">Admin Login</a></p>
</body>
</html>
