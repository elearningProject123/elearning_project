// Example JavaScript code for your e-learning platform

// Function to confirm course deletion
function confirmDeleteCourse(courseId) {
    if (confirm("Are you sure you want to delete this course?")) {
        // If user confirms, redirect to delete_course.php with course ID
        window.location.href = "courses/delete_course.php?course_id=" + courseId;
    }
}

// Function to confirm lesson deletion
function confirmDeleteLesson(lessonId) {
    if (confirm("Are you sure you want to delete this lesson?")) {
        // If user confirms, redirect to delete_lesson.php with lesson ID
        window.location.href = "lessons/delete_lesson.php?lesson_id=" + lessonId;
    }
}

// Example of handling form submission with JavaScript
document.getElementById("myForm").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent default form submission

    // Get form data
    var formData = new FormData(this);

    // Example: Send form data using AJAX
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "process_form.php", true);
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            // Handle response from server
            console.log(xhr.responseText);
        }
    };
    xhr.send(formData);
});
