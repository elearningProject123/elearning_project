<?php
// Database configuration
$db_host = 'localhost'; // Database host (e.g., localhost)
$db_port = '5432'; // Database port (default PostgreSQL port is 5432)
$db_name = 'niraj'; // Database name
$db_username = 'your_username'; // Database username
$db_password = 'your_password'; // Database password

// Establish database connection
$conn = pg_connect("host=$db_host port=$db_port dbname=$db_name user=$db_username password=$db_password");

// Check connection
if (!$conn) {
    die("Connection failed: " . pg_last_error());
}
?>
