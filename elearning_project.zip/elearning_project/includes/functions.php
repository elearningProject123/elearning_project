<?php
// Include the database connection
include('db_connection.php');

// Function to sanitize input data
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Function to fetch all courses from the database
function get_all_courses() {
    global $conn;
    $query = "SELECT * FROM courses";
    $result = pg_query($conn, $query);
    $courses = array();
    while ($row = pg_fetch_assoc($result)) {
        $courses[] = $row;
    }
    return $courses;
}

// Function to delete a course from the database
function delete_course($course_id) {
    global $conn;
    $course_id = sanitize_input($course_id);
    $query = "DELETE FROM courses WHERE id = $course_id";
    $result = pg_query($conn, $query);
    return $result;
}

// Add more functions as needed for managing lessons, users, etc.
?>
